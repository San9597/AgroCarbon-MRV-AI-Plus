// Theme toggle
document.getElementById('themeToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
});

// Voice log (demo)
function startVoiceLog() {
  if (!('webkitSpeechRecognition' in window)) {
    alert('Speech recognition not supported in this browser.');
    return;
  }
  const recognition = new webkitSpeechRecognition();
  recognition.lang = 'en-US';
  recognition.onresult = function(event) {
    document.getElementById('logOutput').innerText = 'Log: ' + event.results[0][0].transcript;
  };
  recognition.start();
}

// IoT simulation
function simulateIoT() {
  document.getElementById('soilMoisture').innerText = (Math.random()*100).toFixed(1);
  document.getElementById('temperature').innerText = (20 + Math.random()*15).toFixed(1);
  document.getElementById('methane').innerText = (1 + Math.random()*10).toFixed(2);
}
setInterval(simulateIoT, 3000);

// Chart (basic)
const ctx = document.getElementById('chart').getContext('2d');
const chart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: ['Jan','Feb','Mar','Apr','May'],
    datasets: [{ label: 'Carbon Savings', data: [10,20,15,30,25] }]
  }
});

// Carbon Wallet
let credits = 0;
function earnCredits() {
  credits += 10;
  document.getElementById('credits').innerText = credits;
}

// Generate MRV Report
function generateReport() {
  const report = {
    farmerLogs: document.getElementById('logOutput').innerText,
    sensors: {
      soilMoisture: document.getElementById('soilMoisture').innerText,
      temperature: document.getElementById('temperature').innerText,
      methane: document.getElementById('methane').innerText
    },
    credits: credits
  };
  document.getElementById('reportOutput').innerText = JSON.stringify(report, null, 2);
}
